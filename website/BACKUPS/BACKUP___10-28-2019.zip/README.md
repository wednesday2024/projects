  Open source:


  Open source license #1: <a href="license_agreements/LICENSE.txt"><button type="button">click here to proceed</button>
  
  
  Open source license #2: <a href="license_agreements/OPEN_SOURCE.txt"><button type="button">click here to proceed</button>
  
  
  Download the website source code: <a href="https://github.com/secretwolf98/secretwolf98.github.io/archive/master.zip"><button type="button">click here to proceed to the download</button>
